#include <iostream>
#include<fstream>
#include<sstream>
#include<string>
using namespace std;

int main()
{

    string arr[63],nam, f,s, st,temp, c="";
    ifstream name ("comp_name.txt");
    if (name.is_open())
    {
        int co =0;
        while(getline(name, nam))
        {
            arr[co]=nam;
            co++;

        }
        name.close();

    }

    else
    {
        cout << "file not found !" << endl;


    }

    for(int i=1 ; i<63 ; i++)
    {
        int coun = -1;
        f= arr[i-1];
        s=arr[i];
        string n="";
        for(int x=0 ; x<s.size(); x++)
        {
            c = s.at(0);
            if( (c>="a"&&c<="z") || (c>="A"&&c<="Z") )
            {
                if(x==0)
                    coun =0;

                x=s.size();

            }
            else
            {
                n=n+c;
                s.erase(0, 1) ;


            }
        }

        if(coun!=0)
        {
            stringstream ss(n);
            ss>>coun;
            f.erase(coun, f.size());
            arr[i]=f+s;

        }



    }

    ofstream dec("deco_name.txt");
    if(dec.is_open())
    {

        for(int i=0 ; i<63; i++)
            dec<<arr[i]<<"\n";


    }






    return 0;
}

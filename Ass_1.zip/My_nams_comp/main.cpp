#include <iostream>
#include<string>
using namespace std;
#include <fstream>
#include<sstream>
int main()
{

    string arr[63],nam,comp[63], f,s, st;
    ifstream name ("names.txt");
    if (name.is_open())
    {
        int co =0;
        while(getline(name, nam))
        {
            arr[co]=nam;
            if(co==0)
                comp[0]=nam;
            co++;

        }
        name.close();

    }

    else
    {
        cout << "file not found !" << endl;


    }
    for(int i=1 ; i<63; i++)
    {
        f=arr[i-1] ;
        int counter=0;
        stringstream ss ;

        int siz_f=f.size();
        s=arr[i];
        int siz_s=s.size();
        if(siz_f<=siz_s)
            siz_s=siz_f;

        for(int j=0 ; j<siz_s ; j++)
        {
            if(f.at(j)==s.at(j))
                counter++;
            else
            {

                j=siz_s;
            }

        }
        if (counter == 0)
        {
            comp[i] = s ;

        }
        else
        {
            s.erase(0, counter ) ;
            comp[i] = s ;
            ss << counter ;
            st = ss.str() ;
            comp[i].insert(0, st) ;

        }



    }
    ofstream comnam("comp_name.txt");

    if(comnam.is_open())
    {

        for(int i=0 ; i<63 ; i++)
        {
            comnam<< comp[i]<<"\n";


        }
    }
    else
    {
        cout<<"file2 not found "<<endl;
    }
    double x=0.0,y=0.0;
    for(int i=0 ; i<63 ; i++)
        x=x+arr[i].size();
    x=x*8;
    cout<<"input = "<<x<<endl;

    for(int i=0 ; i<63 ; i++)
        y=y+comp[i].size();
    y=y*8;
    cout<<"output = "<<y<<endl;

    cout<<"Compression ratio is : "<<y/x;

    return 0;
}
